package com.nyi.yureport.vos

class PhNoVO(var phno : String, var link : String) {

    constructor() : this("", "")
}
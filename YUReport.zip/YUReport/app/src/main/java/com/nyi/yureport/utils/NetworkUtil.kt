package com.nyi.yureport.utils

import android.content.Context
import android.support.v4.content.ContextCompat.getSystemService

class NetworkUtil {

    fun checkNetwork() : Boolean{

        return true
    }
}